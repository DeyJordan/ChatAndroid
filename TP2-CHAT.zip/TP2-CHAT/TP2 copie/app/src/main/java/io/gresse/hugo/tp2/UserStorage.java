package io.gresse.hugo.tp2;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.ArrayList;

/**
 * Created by Dey Jordan on 04/12/2017.
 */

public class UserStorage {

    public static void saveUserInfo(Context context, String name, String email) {
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(context).edit();
        editor.putString("USER_EMAIL", email);
        editor.putString("USER_NAME", name);
        editor.apply();
    }

    public static User getUser(Context context){
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String email = sharedPreferences.getString("USER_EMAIL", null);
        String name = sharedPreferences.getString("USER_NAME", null);
        User user =  new User(email, name);
        return user;
    }

    public static String getUserEmail(Context context){
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String email = sharedPreferences.getString("USER_EMAIL", null);
        return email;
    }

    public static String getUserName(Context context){
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String name = sharedPreferences.getString("USER_NAME", null);
        return name;
    }

    public static boolean isConnected(Context context){
        if(getUserName(context) == null){
            return false;
        }
        return true;
    }

}
