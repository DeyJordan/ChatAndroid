package io.gresse.hugo.tp2;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Display chat messages
 * <p>
 * Created by Hugo Gresse on 26/11/2017.
 */

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {


    private List<Message> mData;

    public MessageAdapter(List<Message> data) {
        mData = data;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_message, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.setData(mData.get(position));
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void setData(List<Message> data) {
        mData = data;
        this.notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        TextView mUserTextView;
        TextView mContentTextView;
        TextView mDateTextView;

        ViewHolder(View itemView) {
            super(itemView);

            mUserTextView = itemView.findViewById(R.id.userTextView);
            mContentTextView = itemView.findViewById(R.id.contentTextView);
            mDateTextView = itemView.findViewById(R.id.dateTextView);
        }

        void setData(Message message) {
            mUserTextView.setText(message.userName + ": ");
            mContentTextView.setText(message.content);
            if(message.timestamp != null) {
                mDateTextView.setText(calculTime(message.timestamp));
            }
        }

        private String calculTime(long timestamp){
            long msPerMinute = 60 * 1000;
            long msPerHour = msPerMinute * 60;
            long msPerDay = msPerHour * 24;
            long msPerMonth = msPerDay * 30;
            long msPerYear = msPerDay * 365;

            long elapsed = System.currentTimeMillis() - timestamp;

            if (elapsed < msPerMinute) {
                return "Il y a " + Math.round(elapsed/1000) + " seconde(s)";
            } else if (elapsed < msPerHour) {
                return "Il y a " + Math.round(elapsed/msPerMinute) + " minute(s)";
            } else if (elapsed < msPerDay ) {
                return "Il y a " + Math.round(elapsed/msPerHour ) + " heure(s)";
            } else if (elapsed < msPerMonth) {
                return "Il y a " + Math.round(elapsed/msPerDay) + " jour(s)";
            } else if (elapsed < msPerYear) {
                return "Il y a " + Math.round(elapsed/msPerMonth) + " moi(s)";
            } else {
                return "Il y a " + Math.round(elapsed / msPerYear) + " an(s)";
            }
        }
    }
}
